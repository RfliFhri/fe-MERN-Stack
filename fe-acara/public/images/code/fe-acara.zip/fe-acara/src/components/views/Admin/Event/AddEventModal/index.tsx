import AddEventModal from "./AddEventModal";

export default AddEventModal;

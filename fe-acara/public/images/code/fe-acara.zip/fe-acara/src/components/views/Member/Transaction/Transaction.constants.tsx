const COLUMN_LISTS_TRANSACTION = [
  { name: "ORDER ID", uid: "orderId" },
  { name: "NOMINAL", uid: "total" },
  { name: "STATUS", uid: "status" },
  { name: "ACTIONS", uid: "actions" },
];

export { COLUMN_LISTS_TRANSACTION };

export enum ROLES {
  ADMIN = "admin",
  MEMBER = "member",
  MANAGER = "manager",
}

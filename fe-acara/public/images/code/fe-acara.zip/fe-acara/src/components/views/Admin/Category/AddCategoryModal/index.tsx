import AddCategoryModal from "./AddCategoryModal";

export default AddCategoryModal;

import PageHead from './PageHead';

export default PageHead;

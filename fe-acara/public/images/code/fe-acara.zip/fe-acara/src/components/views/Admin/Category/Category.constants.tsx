const COLUMN_LISTS_CATEGORY = [
  { name: "ICON", uid: "icon" },
  { name: "NAME", uid: "name" },
  { name: "DESCRIPTION", uid: "description" },
  { name: "ACTIONS", uid: "actions" },
];

export { COLUMN_LISTS_CATEGORY };

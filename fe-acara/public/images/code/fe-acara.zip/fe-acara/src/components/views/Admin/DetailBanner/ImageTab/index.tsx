import ImageTab from "./ImageTab";

export default ImageTab;

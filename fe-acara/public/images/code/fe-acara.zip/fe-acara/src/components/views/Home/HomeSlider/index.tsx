import HomeSlider from "./HomeSlider";

export default HomeSlider;

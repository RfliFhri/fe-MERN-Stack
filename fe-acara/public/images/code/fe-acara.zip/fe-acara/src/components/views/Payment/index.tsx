import Payment from "./Payment";

export default Payment;

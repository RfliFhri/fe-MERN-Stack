import { ICart } from "@/types/Ticket";

const defaultCart: ICart = {
  events: "",
  ticket: "",
  quantity: 0,
};

export { defaultCart };

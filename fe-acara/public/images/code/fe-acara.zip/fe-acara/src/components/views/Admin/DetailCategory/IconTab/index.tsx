import IconTab from "./IconTab";

export default IconTab;

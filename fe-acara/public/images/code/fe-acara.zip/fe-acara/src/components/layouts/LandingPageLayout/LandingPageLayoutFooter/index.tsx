import LandingPageLayoutFooter from "./LandingPageLayoutFooter";

export default LandingPageLayoutFooter;

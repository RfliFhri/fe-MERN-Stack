import HomeCategoryList from "./HomeCategoryList";

export default HomeCategoryList;

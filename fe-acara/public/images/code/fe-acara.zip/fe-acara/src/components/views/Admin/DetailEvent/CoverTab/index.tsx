import CoverTab from "./CoverTab";

export default CoverTab;

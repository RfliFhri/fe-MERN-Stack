const COLUMN_LISTS_EVENT = [
  { name: "BANNER", uid: "banner" },
  { name: "NAME", uid: "name" },
  { name: "START DATE", uid: "startDate" },
  { name: "END DATE", uid: "endDate" },
  { name: "STATUS", uid: "isPublish" },
  { name: "ACTIONS", uid: "actions" },
];

export { COLUMN_LISTS_EVENT };

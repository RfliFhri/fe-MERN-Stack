import SecurityTab from "./SecurityTab";

export default SecurityTab;

import DeleteEventModal from "./DeleteEventModal";

export default DeleteEventModal;

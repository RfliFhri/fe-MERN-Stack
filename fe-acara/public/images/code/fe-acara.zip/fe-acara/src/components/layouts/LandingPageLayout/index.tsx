import LandingPageLayout from "./LandingPageLayout";

export default LandingPageLayout;

interface ICategory {
  _id?: string;
  name?: string;
  description?: string;
  icon?: string | FileList;
}

export type { ICategory };

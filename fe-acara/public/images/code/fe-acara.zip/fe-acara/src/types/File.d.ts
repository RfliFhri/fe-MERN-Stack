interface IFileURL {
  fileUrl: string;
}

export { IFileURL };

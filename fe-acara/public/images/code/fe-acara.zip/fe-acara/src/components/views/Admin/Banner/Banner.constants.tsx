const COLUMN_LISTS_BANNER = [
  { name: "IMAGE", uid: "image" },
  { name: "TITLE", uid: "title" },
  { name: "SHOW", uid: "isShow" },
  { name: "ACTIONS", uid: "actions" },
];

export { COLUMN_LISTS_BANNER };

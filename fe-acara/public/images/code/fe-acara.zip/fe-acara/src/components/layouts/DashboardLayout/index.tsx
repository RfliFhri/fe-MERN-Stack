import DashboardLayout from "./DashboardLayout";

export default DashboardLayout;

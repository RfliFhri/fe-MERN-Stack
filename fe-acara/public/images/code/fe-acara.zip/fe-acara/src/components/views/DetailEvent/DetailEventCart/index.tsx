import DetailEventCart from "./DetailEventCart";

export default DetailEventCart;

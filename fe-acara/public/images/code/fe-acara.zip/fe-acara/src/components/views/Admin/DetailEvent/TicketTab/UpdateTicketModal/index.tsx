import UpdateTicketModal from "./UpdateTicketModal";

export default UpdateTicketModal;

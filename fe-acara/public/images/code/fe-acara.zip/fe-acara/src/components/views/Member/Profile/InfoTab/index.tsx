import InfoTab from "./InfoTab";

export default InfoTab;

import ProfileTab from "./PictureTab";

export default ProfileTab;

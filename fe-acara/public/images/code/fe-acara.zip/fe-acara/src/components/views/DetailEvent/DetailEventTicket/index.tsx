import DetailEventTicket from "./DetailEventTicket";

export default DetailEventTicket;

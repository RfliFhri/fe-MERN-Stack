import RegisterSuccess from "./RegisterSuccess";

export default RegisterSuccess;

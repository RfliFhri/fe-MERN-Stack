import DeleteTransactionModal from "./DeleteTransactionModal";

export default DeleteTransactionModal;

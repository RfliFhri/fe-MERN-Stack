import CardEvent from "./CardEvent";

export default CardEvent;

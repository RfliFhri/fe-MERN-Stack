import DeleteCategoryModal from "./DeleteCategoryModal";

export default DeleteCategoryModal;

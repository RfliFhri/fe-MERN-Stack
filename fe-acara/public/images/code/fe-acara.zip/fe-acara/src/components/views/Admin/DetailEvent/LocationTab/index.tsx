import LocationTab from "./LocationTab";

export default LocationTab;

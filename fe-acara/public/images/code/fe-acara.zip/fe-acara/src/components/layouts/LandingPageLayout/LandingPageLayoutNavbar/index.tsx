import LandingPageLayoutNavbar from "./LandingPageLayoutNavbar";

export default LandingPageLayoutNavbar;

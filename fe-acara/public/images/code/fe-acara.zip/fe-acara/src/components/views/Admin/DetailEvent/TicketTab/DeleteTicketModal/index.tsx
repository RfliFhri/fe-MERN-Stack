import DeleteTicketModal from "./DeleteTicketModal";

export default DeleteTicketModal;

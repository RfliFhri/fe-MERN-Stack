import DeleteBannerModal from "./DeleteBannerModal";

export default DeleteBannerModal;

import DetailBanner from "./DetailBanner";

export default DetailBanner;

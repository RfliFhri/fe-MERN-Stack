import EventFooter from "./EventFooter";

export default EventFooter;

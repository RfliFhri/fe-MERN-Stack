import DetailCategory from "./DetailCategory";

export default DetailCategory;

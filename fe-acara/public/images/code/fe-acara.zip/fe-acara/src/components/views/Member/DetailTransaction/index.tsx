import DetailTransaction from "./DetailTransaction";

export default DetailTransaction;

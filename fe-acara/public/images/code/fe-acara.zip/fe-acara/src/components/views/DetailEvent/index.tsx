import DetailEvent from "./DetailEvent";

export default DetailEvent;

import Activation from "./Activation";

export default Activation;

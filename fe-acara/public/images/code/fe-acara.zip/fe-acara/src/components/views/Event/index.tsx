import Event from "./Event";

export default Event;

import Category from "./Category";

export default Category;
